Code for some problems discussed at InterviewKickstart
