/*
 * trees.c
 *
 *      Author: Gayatri
 */


#include <stdio.h>
#include <limits.h>
#include <stdlib.h>
#include <stdbool.h>
#include "trees.h"

int min(int a, int b) {
	return ((a < b) ? a : b);
}
